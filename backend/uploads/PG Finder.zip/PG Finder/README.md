# PGFinder

1.First the user register's .Then after registering if he/she is a owner then he will be directed to the owner dashboard otherwise to the tenant dashboard

2.after logging In the the user can see all the PG's as well as the single pg .The user can also update the password by using forgot password.As well as update the details of his profile

3.A tenant can book a Pg by going to /bookPG route

4.Owner get's the request for PG for which he can approve it or reject it. By default it will have a status of pending

5.A user can also add review for a particular PG 