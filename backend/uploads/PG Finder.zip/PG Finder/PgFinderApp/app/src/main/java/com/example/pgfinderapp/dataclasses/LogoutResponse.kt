package com.example.pgfinderapp.dataclasses

data class LogoutResponse(
    val msg: String
)
