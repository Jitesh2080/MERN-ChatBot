package com.example.pgfinderapp.dataclasses

data class LoginResponse(
    val message: String = "",
    val email: String = "",
    val role: String = ""
)
