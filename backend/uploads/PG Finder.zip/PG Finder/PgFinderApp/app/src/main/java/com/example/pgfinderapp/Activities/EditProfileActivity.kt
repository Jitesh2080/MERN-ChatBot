package com.example.pgfinderapp.Activities

class EditProfileActivity
{
}